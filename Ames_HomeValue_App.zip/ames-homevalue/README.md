# Ames HomeValue — ML-backed home price estimator

## Run

```bash
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000 in your browser.

Upload the **Ames Housing `train.csv`** from the Kaggle House Prices - Advanced Regression Techniques dataset using the website upload interface, or place it beside `app.py` before starting the server.

The app uses real `SalePrice` labels and 13 human-understandable inputs. It trains a compact histogram gradient boosting regressor, evaluates on a fixed 20% holdout (RMSE, MAE, R²), and retrains on all labeled rows for inference. Simple optional fields use training medians. The displayed low–high band is illustrative +/- 1.5 × holdout MAE, **not** a statistically calibrated confidence interval. All records are historic Ames, Iowa sales, mostly 2006–2010; the results are not current market appraisals. `Neighborhood` entries are categorical dataset labels, not georeferenced coordinates: the map-style neighbourhood picker is not a literal boundary map.

For user experience, `OverallQual` is entered on 5 levels then mapped to the original 1–10 dataset rating using 2,4,6,8,10; the labels are approximate descriptions.
