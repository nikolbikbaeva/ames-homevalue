from pathlib import Path
import json
import numpy as np
import pandas as pd
from flask import Flask, request, jsonify, send_from_directory
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'train.csv'
app = Flask(__name__, static_folder='.')
MODEL = None
STATS = None
FIELDS = ['Neighborhood','BldgType','GrLivArea','BedroomAbvGr','FullBath','HalfBath','OverallQual','YearBuilt','GarageCars','TotalBsmtSF','LotArea','CentralAir','Fireplaces']
NUMS = [f for f in FIELDS if f not in ['Neighborhood','BldgType','CentralAir']]
CATS = ['Neighborhood','BldgType','CentralAir']

def build():
 global MODEL, STATS
 if not DATA.exists():
  MODEL=None; STATS=None; return
 df=pd.read_csv(DATA)
 missing=set(FIELDS+['SalePrice'])-set(df.columns)
 if missing: raise ValueError('Dataset missing columns: '+', '.join(sorted(missing)))
 df=df.dropna(subset=['SalePrice']); x=df[FIELDS].copy(); y=df['SalePrice']
 for c in NUMS: x[c]=pd.to_numeric(x[c],errors='coerce')
 for c in CATS: x[c]=x[c].fillna('Unknown').astype(str)
 prep=ColumnTransformer([('nums',SimpleImputer(strategy='median'),NUMS),('cats',OneHotEncoder(handle_unknown='ignore',sparse_output=False),CATS)])
 model=Pipeline([('preprocess',prep),('model',HistGradientBoostingRegressor(max_iter=140,max_leaf_nodes=15,learning_rate=.075,l2_regularization=10,random_state=42))])
 xt,xv,yt,yv=train_test_split(x,y,test_size=.2,random_state=42)
 model.fit(xt,yt); predictions=model.predict(xv)
 metrics=dict(mae=round(mean_absolute_error(yv,predictions)),rmse=round(np.sqrt(mean_squared_error(yv,predictions))),r2=round(r2_score(yv,predictions),3),n=len(df),validation=len(yv))
 model.fit(x,y)
 STATS={'metrics':metrics,'neighborhoods':sorted(df['Neighborhood'].dropna().unique().tolist()),'medians':{k:float(df[k].median()) for k in NUMS},'neighborhood_medians':{str(k):round(float(v)) for k,v in df.groupby('Neighborhood').SalePrice.median().items()},'sale_price_median':round(float(y.median()))}
 MODEL=model

@app.get('/')
def index(): return send_from_directory(ROOT,'index.html')

@app.get('/api/status')
def status(): return jsonify({'ready':MODEL is not None,'stats':STATS,'message':'Add the Kaggle Ames Housing train.csv file to this folder to enable predictions.' if MODEL is None else 'Trained on Ames Housing sale prices (2006–2010).'})

@app.post('/api/upload')
def upload():
 f=request.files.get('file')
 if not f or not f.filename.lower().endswith('.csv'): return jsonify({'error':'Select a .csv dataset.'}),400
 if request.content_length and request.content_length>12_000_000:return jsonify({'error':'File too large.'}),413
 temp=ROOT/'training_upload.tmp'; f.save(temp)
 try:
  df=pd.read_csv(temp,nrows=5)
  if not set(FIELDS+['SalePrice']).issubset(df.columns):raise ValueError('This is not the Kaggle Ames train.csv (required housing columns not found).')
  temp.replace(DATA);build();return status()
 except Exception as e:
  temp.unlink(missing_ok=True);return jsonify({'error':str(e)}),400

@app.post('/api/predict')
def predict():
 if MODEL is None:return jsonify({'error':'Upload train.csv before estimating prices.'}),503
 obj=request.get_json(silent=True) or {}
 record={}
 for f in FIELDS:
  record[f]=str(obj.get(f,'Unknown')) if f in CATS else float(obj.get(f,STATS['medians'][f]))
 if record['Neighborhood'] not in STATS['neighborhoods']:return jsonify({'error':'Select a neighbourhood in the Ames training dataset.'}),400
 if not 200<=record['GrLivArea']<=10000 or not 1800<=record['YearBuilt']<=2026:return jsonify({'error':'Please check the floor area and construction year.'}),400
 price=max(10000,round(float(MODEL.predict(pd.DataFrame([record]))[0])/100)*100)
 # MAE is a global hold-out metric, not an uncertainty-calibrated interval.
 mae=STATS['metrics']['mae']
 return jsonify({'price':price,'price_per_sqft':round(price/record['GrLivArea']),'illustrative_low':round(max(0,price-1.5*mae)/100)*100,'illustrative_high':round((price+1.5*mae)/100)*100,'metrics':STATS['metrics']})

try:build()
except Exception as e:print('Training error:',e)
if __name__=='__main__': app.run(host='127.0.0.1',port=5000,debug=False)
